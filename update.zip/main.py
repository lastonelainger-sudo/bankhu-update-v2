
import sys, os
from PySide6.QtWidgets import QApplication
from core.update_checker import check_update
from ui.main_window import MainWindow

def main():
    app = QApplication(sys.argv)

    window = MainWindow()
    window.show()

    # run update check
    check_update(window)

    sys.exit(app.exec())

if __name__ == "__main__":
    main()
