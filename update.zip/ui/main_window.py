
from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel
from PySide6.QtCore import QTimer

class MainWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("บ้านคู่หู")

        self.layout = QVBoxLayout()
        self.setLayout(self.layout)

        self.status_label = QLabel("พร้อมใช้งาน")
        self.layout.addWidget(self.status_label)

    def set_status(self, text):
        self.status_label.setText(text)

    def show_bubble(self, text):
        bubble = QLabel(text, self)
        bubble.setStyleSheet("background:#1E1E1E;color:#EAEAEA;padding:10px;border-radius:10px;")
        bubble.move(50, 50)
        bubble.show()
        QTimer.singleShot(3000, bubble.deleteLater)
