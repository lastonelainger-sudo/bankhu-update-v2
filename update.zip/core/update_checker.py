
import requests
from PySide6.QtCore import QTimer

CURRENT_VERSION = "1.0.0"

def check_update(window):
    def run():
        window.set_status("🔍 กำลังเช็คอัปเดต...")
        try:
            data = requests.get("https://raw.githubusercontent.com/example/version.json", timeout=3).json()
            latest = data.get("version", CURRENT_VERSION)

            if latest != CURRENT_VERSION:
                window.set_status(f"✨ มีเวอร์ชันใหม่: {latest}")
                window.show_bubble(f"🥚 เพื่อนไข่: มีอัปเดตใหม่ ({latest})")
            else:
                window.set_status("✅ เวอร์ชันล่าสุดแล้ว")

        except Exception:
            window.set_status("❌ เช็คไม่สำเร็จ")

    QTimer.singleShot(1000, run)
